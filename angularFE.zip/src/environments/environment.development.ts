export const environment = {
    production: false,
    supabase: {
        url: 'https://xwalkjrhpwdizfqqcqbk.supabase.co',
        key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3YWxranJocHdkaXpmcXFjcWJrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDAwNDI3NzYsImV4cCI6MjAxNTYxODc3Nn0.cIlJeR6-pVQGtB7qwSktOQbh6vVgEVCqYtGlgYOULuU'
    }
};
